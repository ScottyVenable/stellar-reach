# Transferable Multi-Agent Pack

This package provides a generic, self-contained multi-agent workflow for coding projects with five named roles: Bridge, Sol, Jesse, Rook, and Vex.

## Included Sets

1. Repository instruction set
- Source path in this package: `repo-template/.github/`
- Destination in target project: `.github/`
- Includes:
  - `copilot-instructions.md`
  - `agents/*.agent.md`

2. VS Code local agent set
- Source path in this package: `workspace-template/.github/agents/`
- Destination in your local workspace root: `.github/agents/`
- Includes:
  - `Bridge.agent.md`
  - `Sol.agent.md`
  - `Jesse.agent.md`
  - `Rook.agent.md`
  - `Vex.agent.md`

3. Optional bootstrap manifest
- Source path in this package: `repo-template/AGENTS.md`
- Destination in target project root: `AGENTS.md`
- Purpose: quick team map and responsibilities reference.

## Quick Install

1. Unzip this package.
2. Copy `repo-template/.github/` into your target project as `.github/`.
3. Copy `workspace-template/.github/agents/` into your local workspace root as `.github/agents/`.
4. Optionally copy `repo-template/AGENTS.md` to the target project root.
5. Open your project in VS Code and verify the custom agents are available.

## Notes

- Templates are intentionally generic and do not reference any specific repository, owner, branch naming convention, lore, or internal docs.
- Branch names, project field names, labels, and quality gates are defined in placeholder form so you can adapt them quickly.
- These templates are instruction assets only; they do not include CI workflows or repository automation scripts.
